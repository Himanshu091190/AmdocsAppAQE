package com.vodafone.streams;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile1 {

	public static void main(String[] args) {
		int ch;
		
		// check if the file exists or not
		FileReader fr = null;
		
		try {
			fr = new FileReader("text");
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
			e.printStackTrace();
		}
		
		// read from FileReader till the end of the file
		try {
			while((ch = fr.read()) != -1)
				System.out.print((char) ch);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// close the file
		try {
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

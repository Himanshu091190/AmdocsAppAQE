package com.vodafone.streams;

import java.io.FileInputStream;

public class CountFile {

	public static void main(String[] args) throws Exception{
		// vars
		int ch;
		boolean prev = true;
		
		// Counters
		int char_count = 0;
		int word_count = 0;
		int line_count = 0;
		
		// Attach the file to FileInputStream to read Data
		FileInputStream fin = new FileInputStream("myfile.txt");
		// read characters from the file till the end
		while((ch = fin.read()) != -1) {
			if(ch != ' ') ++ char_count;
			if(!prev && ch == ' ') ++ word_count;
			// dont count if previous char is space
			if(ch == ' ') prev = true; else prev = false;
			if(ch == '\n') ++ line_count;
		}
		// Display the count of characters, words and lines
		char_count -= line_count*2;
		word_count += line_count;
		System.out.println("No of Characters: " + char_count);
		System.out.println("No of Words: " + word_count);
		System.out.println("No of Lines: " + line_count);
		
		// close the file
		fin.close();
	}
}

package com.vodafone.streams;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class GetObject {

	public static void main(String[] args) throws Exception {
		// To read Objects from the objfile
		FileInputStream fis = new FileInputStream("objfile");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		// read Objects and display till a null object is read
		try {
			Employee e;
			while((e = (Employee) ois.readObject()) != null) 
				e.display();	
		}
		catch(EOFException e) {
			System.out.println("End of File reached !! ");
		}
		finally {
			ois.close();
		}
	}
}

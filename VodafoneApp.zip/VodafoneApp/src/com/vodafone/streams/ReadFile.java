package com.vodafone.streams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		// Attach File to FileInputStream
		FileInputStream fin = null;
		try {
			fin = new FileInputStream("myfile.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println("File Contents are: \n");
		
		// read Characters from the FileInputStream and write them to monitor. Repeat this till the end of the file
		int ch;
		try {
			while((ch = fin.read()) != -1)
				System.out.print((char) ch);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// close the file
		try {
			fin.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

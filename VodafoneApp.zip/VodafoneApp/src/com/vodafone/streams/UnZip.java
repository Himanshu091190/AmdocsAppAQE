package com.vodafone.streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.InflaterInputStream;

public class UnZip {

	public static void main(String[] args) throws Exception{
		// Attach input file: file2 to FileInputStream for reading data
		FileInputStream fis = new FileInputStream("file2");
		
		// Attach Output File: file3 to FileOutputStream for writing the data into it
		FileOutputStream fos = new FileOutputStream("file3");
		
		// Attach the InflaterInputStream to FileInutStream for Uncompressing the data
		InflaterInputStream iis = new InflaterInputStream(fis);
		
		// Read Data from InflaterInputStream and write it into FileOutputStream
		int data;
		while((data = iis.read()) != -1)
			fos.write(data);
		
		// close the files
		fos.close();
		iis.close();
	}

}

package com.vodafone.streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class CopyFile {

	public static void main(String[] args) throws Exception{
		int ch;
		
		// Create a Stream for reading the data
		FileInputStream fin = new FileInputStream("myfile.txt");
		
		// Create a Stream for Writing the data
		FileOutputStream fout = new FileOutputStream("myDetails");
		
		// read from FileInputStream and write into FileOutputStream
		while((ch = fin.read()) != -1)
			fout.write(ch);
		
		// close the files
		fin.close();
		fout.close();
		
		System.out.println("1 File Copied Successfully");
	}
}

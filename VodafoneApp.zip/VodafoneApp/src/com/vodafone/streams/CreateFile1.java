package com.vodafone.streams;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CreateFile1 {

	public static void main(String[] args) {
		// Attach a KeyBoard to DataInputStream
		DataInputStream dis = new DataInputStream(System.in);
		
		// Attach myFile to FileOutputStream
		FileOutputStream fout = null;
		try {
			fout = new FileOutputStream("myfile.txt", true);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		BufferedOutputStream bout = new BufferedOutputStream(fout, 1024);
		System.out.println("Enter Text (@ at the end): ");
		
		char ch;
		
		// read characters from dis into ch. Then weite them into foout and repeat this as long as the read character is not @
		try {
			while((ch = (char) dis.read()) != '!')
				bout.write(ch);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// close the file
		try {
			bout.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

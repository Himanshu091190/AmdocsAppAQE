package com.vodafone.streams;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// instance variables
	int id;
	String name;
	float sal;
	Date doj;

	public Employee(int id, String name, float sal, Date doj) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.doj = doj;
	}
	
	// to display employee details
	void display() {
		System.out.println(id + "\t" + name + "\t" + sal + "\t" + doj);
	}

	static Employee getData() throws Exception {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		
		// accept employee idnumber, name, and salary
		System.out.println("Enter the Employee id: ");
		int id = Integer.parseInt(buff.readLine());
		
		System.out.println("Enter the Employee Name: ");
		String name = buff.readLine();
		
		System.out.println("Enter the Employee Salary: ");
		float sal = Float.parseFloat(buff.readLine());
		
		// Take Current System Date and Time as for Joining
		Date d = new Date();
		
		// create Employee Object with the accepted Data
		Employee e = new Employee(id, name, sal, d);
		
		// return the Employee Object
		return e;
	}
}

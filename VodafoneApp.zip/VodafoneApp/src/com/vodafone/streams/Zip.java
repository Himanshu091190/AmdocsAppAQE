package com.vodafone.streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.DeflaterOutputStream;

public class Zip {

	public static void main(String[] args) throws Exception{
		// Attach the original file: file1 to FileInputStream for Reading the Data
		FileInputStream fis = new FileInputStream("myfile.txt");
		
		// Attach Compressed file: file2 to FileOutputStream
		FileOutputStream fos = new FileOutputStream("file2");
		
		// Attach FileOutputStream to DeflaterOutputStream
		DeflaterOutputStream dos = new DeflaterOutputStream(fos);
		
		// read Data from FileInputStream and write it into DeflaterOutputStream
		int data;
		while((data = fis.read()) != -1)
			dos.write(data);
		
		fis.close();
		dos.close();
	}
}

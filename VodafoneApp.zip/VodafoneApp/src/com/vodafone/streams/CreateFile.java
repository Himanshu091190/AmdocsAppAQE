package com.vodafone.streams;

import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) {
		// Attach a KeyBoard to DataInputStream
		DataInputStream dis = new DataInputStream(System.in);
		
		// Attach myFile to FileOutputStream
		FileOutputStream fout = null;
		try {
			fout = new FileOutputStream("myfile.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		System.out.println("Enter Text (@ at the end): ");
		
		char ch;
		
		// read characters from dis into ch. Then weite them into foout and repeat this as long as the read character is not @
		try {
			while((ch = (char) dis.read()) != '@')
				fout.write(ch);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// close the file
		try {
			fout.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

package com.vodafone.streams;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class ReadDirectory {

	public static void main(String[] args) throws Exception {
		// Enter the path and directory name from the console 
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the Directory path: ");
		String dirPath = buff.readLine();
		
		System.out.println("Enter the Directory Name: ");
		String dirName = buff.readLine();
		
		// Create File Object with DirPath and DirName
		File f = new File(dirPath, dirName);
		
		// if Directory exists, then
		if(f.exists()) {
			// get the contents of the directory into arr[], and then arr[i] will represents either a file or a sub directory
			String arr[] = f.list();
			
			// now we will find the number of entries in the directory
			int n = arr.length;
			
			// display the entries
			for(int i=0; i<n; i++) {
				System.out.print(arr[i]);
				// Create File Object with the entry and test if it is a file or Directory
				File f1 = new File(arr[i]);
				if(f1.isFile()) System.out.println(" : is a file");
				if(f1.isDirectory()) System.out.println(" : is a Directory");
			}
			System.out.println("No of Entries in this Directory: " + n);
		}
		else
			System.out.println("Directory Entered as " + dirName + " Does not Exists, Please Check !!");
	}
}

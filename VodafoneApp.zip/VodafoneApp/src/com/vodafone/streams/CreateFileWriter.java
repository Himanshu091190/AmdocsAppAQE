package com.vodafone.streams;

import java.io.FileWriter;
import java.io.IOException;

public class CreateFileWriter {
	public static void main(String[] args) {
		// Take a String
		String str = "This is a Program on Java. " + "\nI am a new Learner of Java. ";
		
		// Attach a File to FileWriter
		FileWriter fw = null;
		try {
			fw = new FileWriter("text");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// read character wise from the String variable str and write it into the FileWriter
		for(int i=0; i<str.length(); i++)
			try {
				fw.write(str.charAt(i));
			} catch (IOException e) {
				e.printStackTrace();
			}
		
		// close the file
		try {
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

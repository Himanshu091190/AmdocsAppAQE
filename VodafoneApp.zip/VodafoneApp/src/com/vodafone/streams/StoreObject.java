package com.vodafone.streams;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;

public class StoreObject {

	public static void main(String[] args) throws Exception {
		// To accept Data from Keyboard
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		
		// To store Objects into ObjFile
		FileOutputStream fos = new FileOutputStream("objfile");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		// ask how many objects user wants to store
		System.out.println("How many Objects you want to store: ");
		int n = Integer.parseInt(buff.readLine());
		
		// Store n Objects into objfile
		for(int i=0; i<n; i++) {
			// Create Employee Object with data from Keyboard
			Employee e1 = Employee.getData();
			
			// Store Employee object into ObjectOutputStream
			oos.writeObject(e1);
		}
		
		// close the objFile
		oos.close();
	}
}

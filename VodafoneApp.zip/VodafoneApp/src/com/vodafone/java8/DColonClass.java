package com.vodafone.java8;

// Double Colon Operator to refer to a constructor

class Sample {
	// instance variable
	private String x;
	
	// constructor
	Sample(String x) {
		this.x = x;
		System.out.println("Constructor Executed: " + x);
	}
}

// Functional Interface with get() method that returns Sample Class Object
interface MyInterface3 {
	Sample get(String str);
}

public class DColonClass {
	public static void main(String[] args) {
		// this lambda expression returns Sample class Object
		MyInterface3 mi = (String x) -> { return new Sample(x); };
		Sample s = mi.get("Called from Lambda Expresison");
		
		// double colon operator refers to Sample class Constructor
		MyInterface3 mi1 = Sample :: new;
		Sample s1 = mi1.get("Called from Double Colon Operator");
	}
}

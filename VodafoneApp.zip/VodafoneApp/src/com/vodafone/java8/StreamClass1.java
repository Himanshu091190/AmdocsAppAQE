package com.vodafone.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// Create a Stream from ArrayList and Collect the elements of a stream into a list
public class StreamClass1 {

	public static void main(String[] args) {
		// create a list to store Integer Objects
		List<Integer> lst = new ArrayList<Integer>();
		
		// add elements to the list
		for(int i = 1; i<10; i++ )
			lst.add(i);
		
		// convert this list into stream using stream()
		Stream<Integer> sm = lst.stream();
		
		// filter the elements which are greater than 5 and collect them into a list using collect(Collectors.toList())
		List<Integer> lst1 = sm.filter(i -> i>5 ).collect(Collectors.toList());
		
		// display the new List
		System.out.println(lst1);
	}
}

// Program to tell whether the Year is Leap or No
package com.vodafone.java8;

import java.time.Year;

public class DateTime6 {

	public static void main(String[] args) {
		// take the year
		int n = 2015;
		
		// create Year class object with this year
		Year y = Year.of(n);
		
		// test if y is leap or not using isLeap()
		boolean flag = y.isLeap(); // flag is true if leap
				
		if(flag)
			System.out.println("Year " + y + " is a Leap Year .");
		else
			System.out.println("Year " + y + " is not a Leap Year .");
	}
}

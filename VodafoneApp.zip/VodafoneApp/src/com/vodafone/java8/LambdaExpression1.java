// A simple Lambda Expression to show message to the user
package com.vodafone.java8;


public class LambdaExpression1 {
	// Create a functional interface with a single abstract method
	interface MyInterface {
		void message();
	}
	
	public static void main(String args[]) {
		// Create a functional Interface reference that refers to the Lambda Expression
		MyInterface mi = () -> { System.out.println("I am a Lambda Expression"); };
		
		// call the method using reference
		mi.message();
	}
}

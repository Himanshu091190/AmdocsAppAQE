package com.vodafone.java8;

// A Simple Anonymous Inner Class Implementation, In this version we are passing lambda expression to thread class object
public class LambdaExpression7 {
	public static void main(String[] args) {
		// Create a thread object and pass the object of anonymous inner class
		Thread t = new Thread(
				// lambda expression to implement run() method
				() -> { System.out.println("This is from the anonymous Inner Class"); }
			);
		
		// run the thread
		t.start();
	}
}

// Lambda Expression that access the variables with class scope and method scope
package com.vodafone.java8;

public class LambdaExpression3 {
	// variable in the class
	int x = 10;
	
	// method in the class
	void method() {
		// variable in the method
		int x = 20;
		
		// create reference of functional interface to the lambda expression
		Runnable r = () -> {
			System.out.println("Variable of the class = " + this.x);
			System.out.println("Variable of the method = " + x);
		};
		
		// create a thread and run it
		Thread t = new Thread(r);
		t.start();
	}
	public static void main(String[] args) {
		// create object to the class and call the method
		LambdaExpression3 exp = new LambdaExpression3();
		exp.method();
	}
}

// create a lambda expression to find sum of 2 integers
package com.vodafone.java8;

public class LambdaExpression2 {

	// create a functional interface with a single abstract method
	interface MyInterface1 {
		void add(int a, int b);
	}

	public static void main(String[] args) {
		// create a functional interface expression which will refer to the lambda expression
		MyInterface1 mi = (int a, int b) -> { System.out.println("Sum = " + (a+b));};
		
		// call the method using refence 
		mi.add(10, 20);
	}
}

package com.vodafone.java8;

public class LambdaExpression5 implements Runnable {

	@Override
	public void run() {
		System.out.println("This is run method of a Thread");
	}
	public static void main(String[] args) {
		// create an object to the class
		LambdaExpression5 obj = new LambdaExpression5();
		
		// Attach a Thread to the Object
		Thread t = new Thread(obj);
		
		// run the thread on the object
		t.start();
	}
}

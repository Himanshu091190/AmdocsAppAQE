package com.vodafone.java8;

public class Bank {

	String bankName;
	Float bankShare;

	public Bank(String bankName, float bankShare) {
		super();
		this.bankName = bankName;
		this.bankShare = bankShare;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public float getBankShare() {
		return bankShare;
	}

	public void setBankShare(float bankShare) {
		this.bankShare = bankShare;
	}

	public Bank toLower() {
		return new Bank(this.bankName.toLowerCase(), this.bankShare);
	}
}

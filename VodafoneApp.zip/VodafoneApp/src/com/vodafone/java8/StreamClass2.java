package com.vodafone.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

// Create a Stream from ArrayList and convert them into array
public class StreamClass2 {

	public static void main(String[] args) {
		// create a list to store Integer Objects
		List<Integer> lst = new ArrayList<Integer>();
		
		// add elements to the list
		for(int i = 1; i<10; i++ )
			lst.add(i);
		
		// convert this list into stream using stream()
		Stream<Integer> sm = lst.stream();
		
		// filter the elements which are lesser than 5 and collect them into an Integer type array using toArray(Integer[] :: new)
		Integer[] arr = sm.filter(i -> i < 5 ).toArray(Integer[]:: new);
		
		// display the array
		for(Integer i: arr)
		System.out.println(i);
	}
}

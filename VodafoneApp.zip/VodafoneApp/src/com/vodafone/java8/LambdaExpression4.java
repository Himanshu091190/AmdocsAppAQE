// Passing Lambda Expression as argument to a method
package com.vodafone.java8;

// we are going to calculate the area of a circle
public class LambdaExpression4 {
	// create a functional interface with one abstract method
	interface Circle {
		void calculate(double radius);
	}
	// a method with functional interface reference ref as its argument
	void circleArea(double radius, Circle ref) {
		ref.calculate(radius); // this will execute the lambda expression
	}
	
	public static void main(String[] args) {
		// create object to the class
		LambdaExpression4 exp = new LambdaExpression4();
		
		// let the functional interface reference refer to the lambda expression
		// this lambda expression mplements the calculate(radius) method
		Circle ref = (r) -> { System.out.println("Area = " + Math.PI * r * r); };
		
		// call the method, pass radius and lambda expression as arguments
		exp.circleArea(20, ref);
	}
}

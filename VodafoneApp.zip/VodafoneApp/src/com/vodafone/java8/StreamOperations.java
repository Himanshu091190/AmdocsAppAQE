package com.vodafone.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// Performing Stream Operations
public class StreamOperations {

	public static void main(String[] args) {
		// take a string type array and convert into a list
		List<String> lst = Arrays.asList("USA", "Japan", "India", "China", "", "Russia", "UK");

		// count the number of Strings with length more than 4 characters
		long n = lst.stream().filter(x -> x.length() > 4).count();
		System.out.println("Number of Strings with Length more than 4: \n" + n);

		// count the number of Strings which starts with "U"
		n = lst.stream().filter(x -> x.startsWith("U")).count();
		System.out.println("Number of Strings Starting with U: \n" + n);

		// remove all the empty Strings from the list and collect them into another list
		List<String> lst1 = lst.stream().filter(x -> !x.isEmpty()).collect(Collectors.toList());
		System.out.println("The List after removing the empty Strings: \n" + lst1);

		// sort the stream and then convert into upper case and then collect into another list
		List<String> lst2 = lst1.stream().sorted().map(x -> x.toUpperCase()).collect(Collectors.toList());
		System.out.println("The List after sorting in uppercase is: " + lst2);
		
		// Convert all the Strings to Capital Letters and Collect them into an array
		String[] arr = lst2.stream().map(x -> x.toUpperCase()).toArray(String[]::new);
		System.out.println("Array of Sorted Strings in Upper Case is: ");
		for(String i: arr)
			System.out.print(i + " , ");
		
		List<Bank> mList = new ArrayList<Bank>();
		mList.add( new Bank("ICICI", 52.5f));
		mList.add( new Bank("AXIS", 51.5f));
		mList.add( new Bank("HDFC", 50.5f));
		mList.add( new Bank("CITI", 49.5f));
		mList.add( new Bank("BOB", 48.5f));
		
		
		 // 1. Bank Name comparator	
        Comparator<Bank> nameComparatorLEx = (Bank1, Bank2) -> Bank1.getBankName().compareTo(Bank2.getBankName());
 
        // sorting on multiple fields (2-level) using Lambda expression
        List<Bank> sortedBankList = mList.stream()
        		.sorted(nameComparatorLEx)
                .collect(Collectors.toList()); // collect sorted Banks to new list
 
        // print new list to console using forEach()
        sortedBankList.stream().forEach(cust -> System.out.println(cust.getBankName()));
        
        Stream<Bank> sm = mList.stream();
        List<Bank> lowerCaseBank = sm.map(bank -> bank.toLower()).collect(Collectors.toList());
        lowerCaseBank.stream().forEach(cust -> System.out.println(cust.getBankName()));
	}
}

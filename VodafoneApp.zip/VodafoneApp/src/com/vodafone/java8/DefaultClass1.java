package com.vodafone.java8;

// An interface with a default method
interface MyInterface2 {
	int add(int x, int y); 
	default int mul( int x, int y) { // this is a default method
		return (x*y);
	}
}

class A implements MyInterface2 {
	public int add(int x, int y) {
		return (x+y);
	}
}


public class DefaultClass1 {

	public static void main(String[] args) {
		// interface reference can refer to the object of its implementation classes
		MyInterface2 mi = new A();
		System.out.println("Sum = " + mi.add(10, 15));
		
		// default method is by default available in implementation class
		System.out.println("Product = " + mi.mul(10, 15));
	}
}

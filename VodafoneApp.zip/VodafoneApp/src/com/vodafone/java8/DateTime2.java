// Using LocalDate and LocalTime class to retrieve Date and Time in Parts

package com.vodafone.java8;

import java.time.LocalDate;
import java.time.LocalTime;

public class DateTime2 {

	public static void main(String[] args) {
		// LocalDate.now() gives System Date into Local Date Object
		LocalDate today = LocalDate.now();
		
		// get the date, month and year from date
		int dd = today.getDayOfMonth();
		int mm = today.getMonthValue();
		int yy = today.getYear();
		
		System.out.println(dd + " / " + mm + " / " + yy );
		
		// LocalTime.now() gives System time into Local time Object
		LocalTime time = LocalTime.now();
		
		// get the hour, minute, second and nano seconds from time
		int h = time.getHour();
		int m = time.getMinute();
		int s = time.getSecond();
		int n = time.getNano();
		
		System.out.println(h + " : " + m + " : " + s + " : " + n);
		
		System.out.println(today);
		System.out.println(time);
	}
}

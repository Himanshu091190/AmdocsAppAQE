// LocalDateTime class to display system data and time and get some data

package com.vodafone.java8;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;

public class DateTime3 {

	public static void main(String[] args) {
		// get the Current Date and Time
		LocalDateTime dt = LocalDateTime.now();
		System.out.println("Local Date Time Object with Current Date and Time: " + dt);

		// create LocalDateTime object with date: 1994-4-15 and time 11:30 AM
		LocalDateTime dt1 = LocalDateTime.of(1994, Month.APRIL, 15, 11, 30);
		System.out.println("Local Date Time Object with Local Date and Time: " + dt1);

		// find out the date and time from 6 months now
		System.out.println("6 months from now: " + dt.plusMonths(6));

		// find out the date and time 6 months before from now
		System.out.println("6 months from ago: " + dt.minusMonths(6));
		
		// get the day of the week for the current date and time
		DayOfWeek dw = dt.getDayOfWeek();
		
		// represent day of week with its name
		String s = dw.name();
		System.out.println("Day of week name: " + s);
		
		// represent day of week with Integer Value
		int n = dw.getValue();
		System.out.println("Day of Week Value: " + n);

	}
}

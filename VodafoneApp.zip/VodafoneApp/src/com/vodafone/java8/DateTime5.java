// Period Class To Know number of Days between two dates
package com.vodafone.java8;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class DateTime5 {

	public static void main(String[] args) {
		// get Today's Date
		LocalDate today = LocalDate.now();
		
		// Create Local Date Object with Date of Birth as Date
		LocalDate birthday = LocalDate.of(1990, Month.JANUARY, 1);
		
		// find the number of days between() method
		Period p = Period.between(birthday, today);
		System.out.println("You are " + p.getYears() + " Years " + p.getMonths() + " Months and " + p.getDays() + "Days Older");
	}
}

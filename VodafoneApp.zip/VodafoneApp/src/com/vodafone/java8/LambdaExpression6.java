package com.vodafone.java8;

// A Simple Anonymous Inner Class Implementation
public class LambdaExpression6 {
	public static void main(String[] args) {
		// Create a thread object and pass the object of anonymous inner class
		Thread t = new Thread(new Runnable() {
			// implement the run method of the Runnable Interface
			public void run() {
				System.out.println("This is from the anonymous Inner Class");
			}
		});
		
		// run the thread
		t.start();
	}
}

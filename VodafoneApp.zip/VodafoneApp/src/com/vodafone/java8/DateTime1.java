// Using LocalDate and LocalTime class to display System Date and Time

package com.vodafone.java8;

import java.time.LocalDate;
import java.time.LocalTime;

public class DateTime1 {

	public static void main(String[] args) {
		// LocalDate.now() gives System Date into Local Date Object
		LocalDate today = LocalDate.now();
		
		// LocalTime.now() gives System time into Local time Object
		LocalTime time = LocalTime.now();
		
		System.out.println(today);
		System.out.println(time);
	}
}

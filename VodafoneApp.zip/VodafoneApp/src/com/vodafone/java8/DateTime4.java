// ZoneID and ZoneDateTime to know the Time Zone of the Country
package com.vodafone.java8;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateTime4 {

	public static void main(String[] args) {
		// get the default timezone.
		ZoneId zone = ZoneId.systemDefault();
		System.out.println("Current Time Zone is " + zone);
		
		// get Date and Time in Default Time Zone
		LocalDateTime  dt = LocalDateTime.now();
		System.out.println("Date and Time in India is: " + dt);
		
		// get the zone identification for Los Angeles
		ZoneId la = ZoneId.of("America/Los_Angeles");
		
		// get the date and time in Los Angeles
		ZonedDateTime zdt = ZonedDateTime.now(la);
		System.out.println("Date and Time in Los Angeles is: " + zdt);
	}
}

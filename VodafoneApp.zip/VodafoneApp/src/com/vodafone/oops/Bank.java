package com.vodafone.oops;

public class Bank {

	int balance;
	int fdAmount;
	String name;
	
	public Bank(int balance, int fdAmount, String name) {
		super();
		this.balance = balance;
		this.fdAmount = fdAmount;
		this.name = name;
	}
	
	public void updateBalance(int amount) {
		this.balance  = this.balance + amount;
	}
	
	public int getUpdatedBalance() {
		return this.balance;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public int getFdAmount() {
		return fdAmount;
	}

	public void setFdAmount(int fdAmount) {
		this.fdAmount = fdAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

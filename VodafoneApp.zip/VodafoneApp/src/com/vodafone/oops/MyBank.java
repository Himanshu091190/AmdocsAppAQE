package com.vodafone.oops;

public class MyBank extends Bank{

	public MyBank(int balance, int fdAmount, String name) {
		super(balance, fdAmount, name);
	}

	@Override
	public void updateBalance(int amount) {
		super.updateBalance(amount);
		balance = amount + 1000;
		System.out.println("Updated Account Balance from Child Class is " + getBalance());
	}
	
	public void updateBalance(int amount , int interest) {
		balance = amount + interest;
		System.out.println("Updated Balance from Overloaded Method is " + balance);
	}
	
	public static void main(String[] args) {
		MyBank mBank = new MyBank(5000, 10000, "Himanshu");
		System.out.println("Account Balance is " + mBank.getBalance());
		System.out.println("FD Amount is " + mBank.getFdAmount());
		System.out.println("Account Holder Name is " + mBank.getName());
		
		System.out.println("Updating Account Balance from Parent Class");
		mBank.updateBalance(10000);
		System.out.println("Updated Balance from Parent Class is " + mBank.getBalance());
		mBank.updateBalance(20000, 10000);
	}
}

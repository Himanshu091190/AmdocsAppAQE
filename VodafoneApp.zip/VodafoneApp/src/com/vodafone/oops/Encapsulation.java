package com.vodafone.oops;


class Employee {
	int id = 1001;
	String name = "Himanshu";
	int balance = 5000;
	String accountNo = "963258741256";
	float interestEarned = 500000.00f;
	String bankName = "ICICI Bank";
	
	void displayDetails() {
		System.out.println("ID is " + id);
		System.out.println("Name is " + name);
		System.out.println("Bank is " + bankName);
	}
}
public class Encapsulation {
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.displayDetails();
	}
}

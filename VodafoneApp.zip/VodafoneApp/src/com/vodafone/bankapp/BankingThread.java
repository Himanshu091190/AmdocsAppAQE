package com.vodafone.bankapp;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BankingThread implements Runnable{

	@Override
	public void run(){
		Customer c = new Customer();
		try {
			BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter your Name");
			String name = buff.readLine();
			System.out.println("Enter your Email");
			String email = buff.readLine();
			System.out.println("Enter your Phone Number");
			String phone = buff.readLine();

			c.setName(name);
			c.setEmail(email);
			c.setPhone(phone);

			System.out.println("Name of Customer is " + c.getName());
			System.out.println("Email of Customer is " + c.getEmail());
			System.out.println("Phone of Customer is " + c.getPhone());

			System.out.println(
					"Welcome to Indian Banking System\nPlease Select Your Choice of Action\n1. Deposit\n2. Withdrawl\n3. FD");
			int choice = Integer.parseInt(buff.readLine());

			switch (choice) {
			case 1:
				System.out.println("Enter the amount you want to deposit");
				int depositAmount = Integer.parseInt(buff.readLine());
				c.depositMoney(depositAmount);
				break;
			case 2:
				System.out.println("Enter the amount you want to withdraw");
				int withdrawAmount = Integer.parseInt(buff.readLine());
				c.withdrawMoney(withdrawAmount);
				break;
			case 3:
				System.out.println("Enter the FD Amount");
				int fdAmount = Integer.parseInt(buff.readLine());
				System.out.println("Enter the number of Years, You want to create FD");
				int fdYears = Integer.parseInt(buff.readLine());
				System.out.println("Enter the Rate of Intererst of FD");
				int fdROI = Integer.parseInt(buff.readLine());
				c.openFD(fdAmount, fdYears, fdROI);
				break;
			default: System.out.println("No Case Match Found !!");
			}	
		}
		catch(Exception e) {
			System.out.println("Exception is " + e);
		}
	}
}

package com.vodafone.bankapp;

// user defined exception to be thrown whenever the balance amount is less than 1000
class MyException extends Exception{
	// store Account Information
	private static int accno[] = {1001, 1002, 1003, 1004, 1005};
	private static String name[] = {"Raja Rao", "Rama Rao", "Subba Rao", "Appa Rao", "Laxmi Devi"};
	private static double bal[] = {10000.00, 12000.00, 5600.50, 999.00, 1100.55};
	
	// Default Constructor
	MyException() {}
	
	// Parameterized Constructor
	MyException(String str) {
		super(str);
	}

	public static void main(String[] args) {
		try {
			// display the heading for the table
			System.out.println("ACCNO" + "\t" + "CUSTOMER" + "\t" + "BALANCE");
			// display actual account information
			for(int i=0; i<=4; i++) {
				System.out.println(accno[i] + "\t" + name[i] + "\t" + bal[i]);
				
				// display own exception if balance is less than 1000
				if(bal[i] < 1000) {
					MyException me = new MyException("Balance amount is less than 1000");
					throw me;
				}
			}// end for		
		}// end try
		catch(MyException me) {
			me.printStackTrace();
		}
	}// end main
}// end class

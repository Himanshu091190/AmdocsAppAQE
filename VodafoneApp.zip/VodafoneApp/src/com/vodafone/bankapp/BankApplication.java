package com.vodafone.bankapp;

public class BankApplication {

	public static void main(String[] args) throws Exception {
		BankingThread bThread = new BankingThread();
		
		// Thread Object will be created in which BankingThread Object will be passed
		Thread t1 = new Thread(bThread);
		t1.start();
	}
}

package com.vodafone.bankapp;

public class BankOperations {
	
	final float minBalance = 5000;
	double balance = minBalance, fdMatureAmount = 0;
	int operationCounter = 0;
	
	public void depositMoney(int amount) {
		balance = balance + amount;
		System.out.println("Updated Balance after Deposit is: " + balance);
	}
	
	public void withdrawMoney(double amount) {
		if(operationCounter > 3) {
			amount = amount + (amount*0.02);
		}
		if((balance - amount) > minBalance) {
			balance = balance - amount;
			operationCounter ++;
		}
		else {
			balance = balance - amount;
			operationCounter ++;	
		}
		System.out.println("Updated Balance after Withdrawl is: " + balance);
	}
	
	public void openFD(int amount, int years, float roi) {
		fdMatureAmount = amount;
		for(int i=1; i<=years; i++) {
			fdMatureAmount = fdMatureAmount + ((fdMatureAmount*roi)/100);
			System.out.println("Amount after " + i + " Year of FD is: " + fdMatureAmount);
		}
	}

}

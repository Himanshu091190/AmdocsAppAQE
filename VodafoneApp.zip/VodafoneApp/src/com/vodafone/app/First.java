package com.vodafone.app;

public class First {
	public static void main(String[] args) {
		// If - Else - If Code Block
//		int num = -5;
//		if(num == 0)
//			System.out.println("It is a Zero Number");
//		else if(num > 0)
//			System.out.println("It is a Positive Number");
//		else
//			System.out.println("It is a Negative Number");

		// Do While Loop
//		int x;
//		x = 1;
//		do {
//			System.out.println(x);
//			x++;
//		}while(x<=10);

		// While Loop
//		int x = 1;
//		while(x<=10) {
//			System.out.println(x);
//			x++;
//		}

		// For Loop
//		for(int i = 1; i<=10; i++)
//			System.out.println(i);

//		int arr[] = {200, 19, -56, 44, 99};
//		for(int i: arr)
//			System.out.println(i);

		// Switch Block
//		char color = 'g'; // color is set to 'g'
//		switch (color) {
//		case 'r':
//			System.out.println("Red");
//			break;
//		case 'g':
//			System.out.println("Green");
//			break;
//		case 'b':
//			System.out.println("Blue");
//			break;
//		case 'w':
//			System.out.println("White");
//			break;
//		default:
//			System.out.println("No color");
//		}
		
		// call myMethod() and catch the result into res
		int res = First.myMethod(10);
		System.out.println("Result = " + res);
	}
	static int myMethod(int num) {
		return num * num; // return square value of number
	}
}

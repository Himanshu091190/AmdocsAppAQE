package com.vodafone.app;

public class StringDemo {

	public static void main(String[] args) {
		// Lets Create Strings in 3 Ways
		String s1 = "A Program on Java";
		String s2 = "I Like Program on Java";
		char arr[] = {'C','O','R','E','J','A','V','A','B','O','O','K'};
		String s3 = new String(arr);
		
		// display Strings
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		
		// find out the length of the first string
		System.out.println("Length of S1 = " + s1.length());
		
		// Concatenate / Join 2 Strings
		System.out.println("S1 and S2 joined " + s1.concat(s2));
		
		// Concatenate / Join 2 Strings with '+' Operator
		System.out.println(s1 + " from " + s3);
		
		// Test if String s1 Starts with A
		boolean test = s1.startsWith("A");
		if(test)
			System.out.println("s1 starts with \'A\'");
		else
			System.out.println("s1 doesnt starts with \'A\'");
		
		// extract substring from s2, starting from 0th Character to 6th Character
		String p = s2.substring(0,7);
		
		// extract substring from s3, starting from 0th Character to 8th Character
		String q = s3.substring(0,9);
		
		// Concatenate / Join Strings P and Q
		System.out.println(p+q);
		
		// Convert S1 to UpperCase and S1 to LowerCase
		System.out.println("Upper Case S1 = " + s1.toUpperCase());
		System.out.println("Lower Case S2 = " + s2.toLowerCase());
		
		// String Delimiter
		// Take a string which is to be broken
		String str = "Helllo, this is a program on Java";
		// declare a string type array to store pieces of broken string
		String s[];
		// split the string where a space is found between 2 words
		s = str.split(" ");
		
		// display the pieces of a string from the array
		for(String st: s)
			System.out.println(st);
		
		// Compare the Strings
		String str1 = "Himanshu";
		String str2 = "Himanshu";
		String str3 = new String("Himanshu");
		if(s2 == s3)
			System.out.println("S2 and S3 are Same");
		else 
			System.out.println("Not Same");
	}

}

package com.vodafone.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Palindrome {
	public static void main(String[] args) throws IOException {
		
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter a String: ");
			String str = buff.readLine();
		
		// store copy of original String in temp variable
			String temp = str;
		
			// convert String into String Buffer
			StringBuffer sb = new StringBuffer(str);
			// reverse the string in StringBuffer
			sb.reverse();
			// convert the string buffer into string
			str = sb.toString();
			
			// compare the original string in temp with reversed string
			if(temp.equalsIgnoreCase(str))
				System.out.println(temp + " is Palindrome");
			else
				System.out.println(temp + " is not palindrome");
	}

}

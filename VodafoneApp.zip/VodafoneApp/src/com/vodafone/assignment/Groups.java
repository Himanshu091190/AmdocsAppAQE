// 3. Write a Program to store a group of objects into an array and retrieve the object data and display.

package com.vodafone.assignment;

import java.io.BufferedReader;
import java.io.InputStreamReader;

class Employee {
	// instance vars
	int id;
	String name;

	// to store data
	Employee(int i, String name) {
		this.id = i;
		this.name = name;
	}

	// a method to display the Data
	void displayData() {
		System.out.println(id + " \t " + name);
	}
}

public class Groups {

	public static void main(String[] args) throws Exception {
		// to accpet data from keyboard
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));

		// Create Employee Type array with size 5
		Employee[] arr = new Employee[5];

		// Store 5 Employee Data into Array
		for (int i = 0; i <= 4; i++) {
			System.out.print("Enter ID: ");
				int id = Integer.parseInt(buff.readLine());
			System.out.print("Enter Name: ");
				String name = buff.readLine();
			
			arr[i] = new Employee(id, name);
		}
		System.out.println("\nThe Employee Data is: ");
		// display the Employees Data from the Array
		for(int i=0; i<=4; i++)
			arr[i].displayData();

	}

}

// 1. write a program that accepts the character from the keyboard and displays its type.

package com.vodafone.assignment;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CharTest {

	public static void main(String[] args) throws Exception {
		// to accept a character from the keyboard and display what it is
		char ch;
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {  // execute repeatedly
			System.out.println("Enter a Character: ");
			ch = (char) buff.read();
			
			// test and display the type of character 
			System.out.print("You entered: ");
			if(Character.isDigit(ch))
				System.out.println(ch + " is a digit");
			else if(Character.isUpperCase(ch))
					System.out.println(ch + " is an UpperCase Letter");
			else if(Character.isLowerCase(ch))
				System.out.println(ch + " is an LowerCase Letter");
			else if(Character.isSpaceChar(ch))
				System.out.println(ch + " is a spacebar Character");
			else if(Character.isWhitespace(ch))
				System.out.println(ch + " is a whitespace Character");
			else
				System.out.println("Sorry I dont know that !!");
			buff.skip(2); // to skip \n code from buff
		}
	}
}

// 6. Write a Program that shows the use of throw clause for throwing the NullPointerException.

package com.vodafone.assignment;


class Sample {
	static void demo() {
		try {
			System.out.println("Inside Demo Method()");
			throw new NullPointerException("Exception Data");
		}
		catch(NullPointerException ne) {
			System.out.println(ne);
		}
	}
}
public class ThrowDemoProgram {
	public static void main(String[] args) {
		Sample.demo();
	}

}

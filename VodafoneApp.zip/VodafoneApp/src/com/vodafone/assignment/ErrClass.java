// 5. An employee got an increment of 15% in his salary and the programmer wants to calculate his incremented salary.
// The programmer has used wrong formula where he is calculating the increment only and not the incremented salary.
// Write a Program related to this.

package com.vodafone.assignment;

public class ErrClass {
	
	public static void main(String[] args) {
		
		double salary = 5000.00;
		salary = salary * 15/100; //Wrong Formula for Calculating Increment Only but it is not added in the Salary
		System.out.println("Incremented Salary = " + salary);
		
		double sal = 5000.00;
		sal += sal * 15/100; // Correct Formula for Calculating the proper Incremented Salary with Increment Added to it
		System.out.println("Incremented Salary with Increment Added to it: " + sal);
	}
}

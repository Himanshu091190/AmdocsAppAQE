// 2. Write a program that generates random numbers repeatedly between "0" & "10". You need to ensure that if the generated number
// is "0" then program gets terminated.

package com.vodafone.assignment;

public class Random {

	public static void main(String[] args) throws Exception {
		System.out.println("Random Numbers between 0 and 10: ");
		while(true) {
			/* random() returns double type between 0 and 1. But we want the no as integer and between 10. So multiply it by
			 *  10 and convert it into int. 
			 */
			double d = 10 * Math.random();
			int i = (int) d;
			System.out.println(i);
			
			// Let the execution wait till 2000 milliseconds = 2 seconds
			Thread.sleep(2000);
			
			if(i == 0)
				System.exit(0);
		}
	}
}

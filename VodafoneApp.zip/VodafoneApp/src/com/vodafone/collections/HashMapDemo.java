package com.vodafone.collections;

import java.util.HashMap;
import java.util.Set;

public class HashMapDemo {
	public static void main(String[] args) {
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("1001", "Appa Rao");
		hm.put("1002", "Subba Rao");
		hm.put("1003", "Raja Rao");
		hm.put("1004", "Anna Rao");
		hm.put("1005", "Laxmi Devi");
		
		System.out.println("Printing the HashMap Values: ");
		Set<String> mKeySet = hm.keySet();
		for(String str: mKeySet)
			System.out.print(hm.get(str)+"\t");
	}
}

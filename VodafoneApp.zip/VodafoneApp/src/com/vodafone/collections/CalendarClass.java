package com.vodafone.collections;

import java.util.Calendar;

public class CalendarClass {
	public static void main(String[] args) {
		// create a Calendar Class object by default it contains the system date and time
		Calendar cl = Calendar.getInstance();
		
		// Display Date Separately
		System.out.println("Current Date is: ");
		int dd = cl.get(Calendar.DATE);
		int mm = cl.get(Calendar.MONTH);
		++mm;
		int yy = cl.get(Calendar.YEAR);
		if(mm < 10)
			System.out.println(dd + " - 0" + mm + " - " + yy);
		else
			System.out.println(dd + " - " + mm + " - " + yy);
		
		// Display Time Alone
		System.out.println("Current Time is: ");
		int h = cl.get(Calendar.HOUR);
		int m = cl.get(Calendar.MINUTE);
		int s = cl.get(Calendar.SECOND);
		System.out.println(h + " : " + m + " : " + s);
		
		int x = cl.get(Calendar.AM_PM);
		if( x ==  0 )
			System.out.println("Good Morning");
		else
			System.out.println("Good Evening");
	}
}

package com.vodafone.collections;

import java.util.ListIterator;
import java.util.Vector;

public class VectorDemo {
	public static void main(String[] args) {
		// Take a vector to store integer objects
		Vector<Integer> v = new Vector<Integer>();
		
		// take an int type array
		int x[] = {22,20,10,40,15,60};
		
		for(int i=0; i<x.length; i++)
			v.add(x[i]);
		
		// retrieve the elements using get()
		System.out.println("Vector Elements: ");
		for(int i=0; i<v.size(); i++)
			System.out.print(v.get(i)+"\t");
		
		// retrieve using ListIterator
		System.out.println("Elements Using ListIterator: ");
		ListIterator lit = v.listIterator();
		
		System.out.println("In Forward Direction: ");
		while(lit.hasNext())
			System.out.print(lit.next()+"\t");
		
		System.out.println("\nIn Backward Direction: ");
		while(lit.hasPrevious())
			System.out.print(lit.previous()+"\t");
	}
}

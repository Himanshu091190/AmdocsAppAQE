package com.vodafone.collections;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class MyDate {
	public static void main(String[] args) {
		// Create Date Class Object which contains system Date and Time by Default
		Date d = new Date();
		
		// Format the date to medium format and time to short format
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.UK);
		
		// Apply the above format to the Date Object
		String str = df.format(d);
		
		// Now Display the Formatted Date and Time
		System.out.println(str);
	}
}

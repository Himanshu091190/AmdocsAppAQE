package com.vodafone.collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		// Create ArrayList
		ArrayList<String> arl = new ArrayList<String>();
		arl.add("Apple");
		arl.add("Mango");
		arl.add("Grapes");
		arl.add("Guava");
		
		// display the contents of arraylist
		System.out.println(arl);
		
		// remove 2 objects
		arl.remove(3);
		arl.remove("Apple");
		System.out.println("Contents of ArrayList after removing elements: " + arl);
		System.out.println("Size of the ArrayList: " + arl.size());
		
		// adding iterator to arrayList to retrieve elements
		Iterator it = arl.iterator();
		while(it.hasNext())
			System.out.println(it.next());
	}
}

package com.vodafone.collections;

import java.util.StringTokenizer;

public class StringTokenizerDemo {
	public static void main(String[] args) {
		// take a String
		String str = "He is a gentle man";
		
		// break into tokens at spaces. Here delimiter is a space
		StringTokenizer st = new StringTokenizer(str, " ");
		
		// retrieve tokens from st and display them all
		System.out.println("The tokens are: ");
		
		while(st.hasMoreTokens()) 
			System.out.println(st.nextToken());
			
	}
}

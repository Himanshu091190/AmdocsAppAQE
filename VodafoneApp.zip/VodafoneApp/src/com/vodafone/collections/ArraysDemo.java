package com.vodafone.collections;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class ArraysDemo {
	public static void main(String[] args) {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		// create an Array
		int arr[] = new int[5];
		// store elements into array
		for(int i=0; i<=4; i++) {
			System.out.println("Enter an Integer: ");
			try {
				arr[i] = Integer.parseInt(buff.readLine());
			} catch (NumberFormatException | IOException e) {
				e.printStackTrace();
			}
		}
		// display the array contents
		System.out.println("Contents of the Array: ");
		display(arr);
		
		// sort the array into ascending order
		Arrays.sort(arr);
		
		// display the sorted contents
		System.out.println("Contents of the Sorted Array: ");
		display(arr);
		
		// Now search for an element
		System.out.println("Which element to be searched ?");
		int element=0;
		try {
			element = Integer.parseInt(buff.readLine());
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}
		int index = Arrays.binarySearch(arr, element);
		if(index<0) System.out.println("Element Not found");
		else System.out.println("Element found at location: " + (index+1));
	}
	
	static void display(int arr[]) {
		for(int i: arr)
			System.out.println(i);
	}
}

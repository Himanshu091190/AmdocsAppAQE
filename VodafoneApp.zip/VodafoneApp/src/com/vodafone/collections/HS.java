package com.vodafone.collections;

import java.util.HashSet;
import java.util.Iterator;

public class HS {
	public static void main(String[] args) {
		// create HashSet to Store Strings
		HashSet<String> hs = new HashSet<String>();
		
		// Store some String elements in that
		hs.add("India");
		hs.add("America");
		hs.add("Japan");
		hs.add("China");
		hs.add("America");
		
		// View Hashset 
		System.out.println("HashSet = " + hs);
		
		// add an iterator to HashSet
		Iterator it = hs.iterator();
		System.out.println("Elements Using Iterator");
		while(it.hasNext()) {
			String s = (String) it.next();
			System.out.println(s);
		}
	}
}

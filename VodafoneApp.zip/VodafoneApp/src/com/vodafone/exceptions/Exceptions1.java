package com.vodafone.exceptions;

// Exception Handling Using Try Catch and Finally Block
public class Exceptions1 {
	public static void main(String[] args) {
		try {
			System.out.println("Perform the Division Operation");
			int a = 45 / 10;
			System.out.println(a);
			int b[] = { 10 , 20 , 30 };
			b[50] = 100;
		}
		catch(ArithmeticException ae) {
			System.out.println("Please check the Denominator value it should not be 0");
		}
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("Please see that Array Index is within the Range");
		}
		finally {
			System.out.println("I am Finally block");
		}
	}
}

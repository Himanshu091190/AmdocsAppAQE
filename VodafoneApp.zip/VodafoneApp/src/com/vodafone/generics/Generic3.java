// A Generic Interface
package com.vodafone.generics;

interface Fruit<T> {
	// method that accepts any Object
	void tellTaste(T fruit); // public abstract
}

// thic class implements Fruit interface
class AnyFruit<T> implements Fruit<T> {

	@Override
	public void tellTaste(T fruit) {
		// know the class name of the object passed to this method
		String fruitName = fruit.getClass().getName();
		
		// then decide the taste and display
		if(fruitName.equalsIgnoreCase("com.vodafone.generics.Banana"))
			System.out.println("Banana is Sweet");
		else if(fruitName.equalsIgnoreCase("com.vodafone.generics.Orange"))
			System.out.println("Orange is Sour");
	}
}
class Banana{}
class Orange{}

public class Generic3 {

	public static void main(String[] args) {
		// create Banana Object and pass it to AnyFruit Class
		Banana b = new Banana();
		AnyFruit<Banana> fruit1 = new AnyFruit<Banana>();
		fruit1.tellTaste(b);

		// create Orange Object and pass it to AnyFruit Class
		Orange o = new Orange();
		AnyFruit<Orange> fruit2 = new AnyFruit<Orange>();
		fruit2.tellTaste(o);
	}
}

// A generic class - to store any type of object
package com.vodafone.generics;

// here, T is generic parameter which determines the datatype
class MyClass<T> {
	// declare T type object
	T obj;
	
	// a constructor to initialize T type object
	MyClass(T obj) {
		this.obj = obj;
	}
	
	// a method which returns T type object
	T getObj() {
		return obj;
	}
}

public class Generic1 {
	public static void main(String[] args) {
		// create Integer Class Object
		Integer i = 12; // This is same as: Integer i = new Integer(12);
		
		// create MyClass object and store Integer object in it
		MyClass<Integer> obj = new MyClass<Integer>(i);
		
		// retrieve Integer Object by calling getObj()
		System.out.println("U Stored: " + obj.getObj());
		
		// In the same way, we use MyClass for storing Float Object and retrieve it
		Float f = 12.123f; // same as: Float f = new Float(12.123f);
		MyClass<Float> obj1 = new MyClass<Float>(f);
		System.out.println("U Stored: " + obj1.getObj());
		
		// we can use MyClass to Store String type Data also
		MyClass<String> obj2 = new MyClass<String>("Himanshu Sharma");
		System.out.println("U Stored: " + obj2.getObj());
		
		
	}
}

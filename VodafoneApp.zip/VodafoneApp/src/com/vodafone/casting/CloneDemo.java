package com.vodafone.casting;

class Employee implements Cloneable {
	// instance variables
	int id;
	String name;
	
	// constructor to initialize the variables
	Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	// method to display the details
	void getData() {
		System.out.println("Id is: " + id);
		System.out.println("Name is: " + name);
	}
	
	// clone the present class object
	public Object myClone() throws CloneNotSupportedException {
		return super.clone();
	}
}

public class CloneDemo {
	public static void main(String[] args) throws CloneNotSupportedException {
		// Creating the Employee Class Object
		Employee e1 = new Employee(10, "Himanshu");
		System.out.println("Original Object:");
		e1.getData();
		
		// Create another object by cloning e1. As myClone() method returns object of Object class type, which will be converted 
		// into Employee Class type Object
		Employee e2 = (Employee) e1.myClone();
		System.out.println("Cloned Object: ");
		e2.getData();
	}
}

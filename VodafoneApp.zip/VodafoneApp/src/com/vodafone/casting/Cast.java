//// Widening using referenced Data Types
//package com.vodafone.casting;
//
//class One {
//	void show1() {
//		System.out.println("Super Class Method");
//	}
//}
//
//class Two extends One{
//	void show2() {
//		System.out.println("Sub Class Method");
//	}
//}
//
//public class Cast {
//
//	public static void main(String[] args) {
//		One o; // o is super class reference
//		o = (One) new Two(); // o is referring to sub class object
//		o.show1();
//	}
//}

// Narrowing using super class object
package com.vodafone.casting;

class One {
	void show1() {
		System.out.println("Super Class Method");
	}
}

class Two extends One{
	void show2() {
		System.out.println("Sub Class Method");
	}
}

public class Cast {

	public static void main(String[] args) {
		One o;
		o = new Two(); // super class reference to refer to sub class object
		Two t = (Two) o; // this is narrowing - convert Class One's reference type as class Two's Type
		t.show1();
		t.show2();
	}
}

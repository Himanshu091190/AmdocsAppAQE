// Callback Mechanism using interfaces in Java
package com.vodafone.abstractinterface;

import java.io.BufferedReader;
import java.io.InputStreamReader;

// Create an interface
interface Tax {
	double stateTax();
}

// Implementation class for AP state Tax 
class AP implements Tax {
	@Override
	public double stateTax() {
		System.out.println("According to the AP Govt Rules");
		return 5000.50;
	}
}
//Implementation class for Karnataka state Tax 
class Karnataka implements Tax {
	@Override
	public double stateTax() {
		System.out.println("According to the Karnataka Govt Rules");
		return 2000.50;
	}
}
public class TaxAppusingCallBack {
	public static void main(String[] args) throws Exception {
		// Accept the state name through the user which we will store in Object c
		System.out.println("Enter the State either as 'AP' or 'Karnataka' to View the State Tax");
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		String stateName = "com.vodafone.abstractinterface." + buff.readLine();
		Class c = Class.forName(stateName);
		// Create a new Object to that class whose name is in c. 
		// Tax interface reference is referencing that new object
		Tax ref = (Tax) c.newInstance();
		calculateTax(ref);
	}
	
	static void calculateTax(Tax t) {
		// Calculate Central Tax
		double ct = 1000.00;
		// Calculate State Tax
		double st = t.stateTax();
		// Display Total Tax
		System.out.println("Total Tax = " + (ct + st));
	}
}

package com.vodafone.abstractinterface;

public class UseCar {
	public static void main(String[] args) {
		// Create Sub Class Objects
		Maruti m = new Maruti(1001); // 1001 is regNo
		Santro s = new Santro(5005); // 5005 is regNo

		// Create a reference to Super Class: Car
		Car ref;

		// to use the Maruti Car
		ref = m; // to use Santro car: ref = s;

		// use the features of the car
		ref.openTank();
		ref.steering(1, 90);
		ref.braking(500);
		
		System.out.println("\t\t\t\t\t\t============================================");
		
		ref = s; 

		// use the features of the car
		ref.openTank();
		ref.steering(1, 90);
		ref.braking(500);
	}
}

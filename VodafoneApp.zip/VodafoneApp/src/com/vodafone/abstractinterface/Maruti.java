package com.vodafone.abstractinterface;

// This is a concrete subclass derived from parent Car class
public class Maruti extends Car{
	
	// Store regNo in super class var
	Maruti(int regNo) {
		super(regNo);
	}

	// Maruti uses Ordinary Steering
	@Override
	void steering(int direction, int angle) {
		System.out.println("Take a Turn\tThis is Ordinary Steering");
	}

	// Maruti uses Hydraulic Brakes
	@Override
	void braking(int force) {
		System.out.println("Brakes Applied\tThese are Hydraulic Brakes");
	}	
}

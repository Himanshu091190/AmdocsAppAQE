package com.vodafone.abstractinterface;

// This is a Concrete Class derived from class Car
public class Santro extends Car{

	// Storing regNo at super class
	Santro(int regNo) {
		super(regNo);
	}

	// Santro uses Power Steering
	@Override
	void steering(int direction, int angle) {
		System.out.println("Take a Turn\tThis Car uses Power Steering");
	}

	// Santro uses Gas Break
	@Override
	void braking(int force) {
		System.out.println("Brakes Applied\tThis Car uses Gas Brakes");
	}

}

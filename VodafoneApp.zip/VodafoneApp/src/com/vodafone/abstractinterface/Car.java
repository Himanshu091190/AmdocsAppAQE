package com.vodafone.abstractinterface;

public abstract class Car {
	// Every Car will have a Registration Number
	int regNo;
	
	// Initialize the value of Registration Number
	Car(int regNo) {
		this.regNo = regNo;
	}
	
	// all Cars will have a fuel tank and same mechanism to open the tank
	void openTank() {
		System.out.println("Fill the tank");
	}
	
	// all cars will have steering but different cars will have different steering mechanisms
	abstract void steering(int direction, int angle);
	
	// all cars will have brakes but different cars will have different braking mechanisms
	abstract void braking(int force);
}

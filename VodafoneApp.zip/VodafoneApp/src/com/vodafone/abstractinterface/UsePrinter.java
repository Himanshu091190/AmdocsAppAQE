package com.vodafone.abstractinterface;

// Create an interface for Printing
interface Printer {
	// to print the text sent to printer
	void printit(String text);
	// to disconnect from printer
	void disconnect();
}

// Implement the Printer Interface for IBM Printer
class IBMPrinter implements Printer {

	@Override
	public void printit(String text) {
		System.out.println(text);
	}

	@Override
	public void disconnect() {
		System.out.println("Printing Completed\tDisconnected from IBM Printer");
	}	
}

//Implement the Printer Interface for Epson Printer
class EpsonPrinter implements Printer {

	@Override
	public void printit(String text) {
		System.out.println(text);
	}

	@Override
	public void disconnect() {
		System.out.println("Printing Completed\tDisconnected from Epson Printer");
	}	
}
public class UsePrinter {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String printerNames[] = {"com.vodafone.abstractinterface.IBMPrinter", "com.vodafone.abstractinterface.EpsonPrinter"};
		// Store the Printer Name in an Object c
		Class c = Class.forName(printerNames[0]);
		// Creating Object of the Class represented by printerName in c
		Printer ref = (Printer) c.newInstance();
		ref.printit("Hello, this is Printed on the Printer");
		ref.disconnect();
	}

}

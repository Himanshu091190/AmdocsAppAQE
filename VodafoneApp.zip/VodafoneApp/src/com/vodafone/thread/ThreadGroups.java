// Using Thread Groups for threads
package com.vodafone.thread;

class Reservation extends Thread {
	@Override
	public void run() {
		System.out.println("I am a reservation thread");
	}
}

class Cancellation extends Thread {
	@Override
	public void run() {
		System.out.println("I am a cancellation thread");
	}
}

public class ThreadGroups {

	public static void main(String[] args) {
		Reservation res = new Reservation();
		Cancellation can = new Cancellation();

		// create a thread group with name first group
		ThreadGroup tg = new ThreadGroup("First Group");

		// create 2 threads and add them to first group
		Thread t1 = new Thread(tg, res, "First Thread");
		Thread t2 = new Thread(tg, res, "Second Thread");

		// create another thread group tg1 as child to tg
		ThreadGroup tg1 = new ThreadGroup("Second Group");

		// create 2 threads and add them to second group
		Thread t3 = new Thread(tg1, can, "Third Thread");
		Thread t4 = new Thread(tg1, can, "Fourth Thread");
		
		// find parent group of tg1
		System.out.println("Parent of tg1 = " + tg1.getParent());
		
		// set maximum priority to tg1 as 7
		tg1.setMaxPriority(7);
		
		// know the thread group of t1 and t3 threads
		System.out.println("Thread Group of t1 = " + t1.getThreadGroup());
		System.out.println("Thread Group of t3 = " + t3.getThreadGroup());
		
		// start the threads
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
		// find how many threads are actively running
		System.out.println("No of threads active in tg = " + tg.activeCount());
	}
}

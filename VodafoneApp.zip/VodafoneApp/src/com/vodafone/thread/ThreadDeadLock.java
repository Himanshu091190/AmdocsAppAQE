// Thread DeadLock Implementation
package com.vodafone.thread;

class BookTicket extends Thread {
	// We are assuming  train, compartment as objects
	Object train, comp;
	
	BookTicket(Object train, Object comp) {
		this.train = train;
		this.comp = comp;
	}
	
	@Override
	public void run() {
		// lock on train object
		synchronized (train) {
			System.out.println("Booked Ticket is Locked on Train Object");
			try {
				Thread.sleep(150);
			}catch(InterruptedException e) {}
			
			System.out.println("Book Ticket now Waiting to Lock on Compartment ... Object");
			synchronized (comp) {
				System.out.println("Book ticket Locked on Compartment ... Object");
			}
		}
	}
}

class CancelTicket extends Thread {
	// We are assuming  train, compartment as objects
		Object train, comp;
		
		CancelTicket(Object train, Object comp) {
			this.train = train;
			this.comp = comp;
		}
		
		@Override
		public void run() {
			// lock on train object
			// synchronized (comp) { // DeadLock Condition
			synchronized (train) {
				System.out.println("Cancel Ticket is Locked on Compartment Object");
				try {
					Thread.sleep(200);
				}catch(InterruptedException e) {}
				
				System.out.println("Cancel Ticket now Waiting to Lock on Train ... Object");
				// synchronized (train) { // DeadLock Condition 
				synchronized (comp) {
					System.out.println("Cancel ticket Locked on Train ... Object");
				}
			}
		}
}

public class ThreadDeadLock {

	public static void main(String[] args) throws Exception{
		// take train, compartment as objects of Object Class
		Object train = new Object();
		Object compartment = new Object();
		
		// create Objects to BookTicket, CancelTicket classes
		BookTicket obj1 = new BookTicket(train, compartment);
		CancelTicket obj2 = new CancelTicket(train, compartment);
		
		// Attach 2 threads to these 2 Objects
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		
		// run the threads on the objects
		t1.start();
		t2.start();
	}
}

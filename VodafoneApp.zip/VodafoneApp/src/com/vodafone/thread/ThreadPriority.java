// Thread Priorities
package com.vodafone.thread;

class MyClass extends Thread {
	int count = 0; // this counts numbers
	
	@Override
	public void run() {
		for(int i=0; i<=10000; i++)
			count++; // count numbers upto 10000
		
		// display which thread has completed counting and its priority
		System.out.println("Completed Thread: " + Thread.currentThread().getName());
		System.out.println("Its Priority is: " + Thread.currentThread().getPriority());
	}
}

public class ThreadPriority {

	public static void main(String[] args) {
		MyClass obj = new MyClass();
		
		// create two threads
		Thread t1 = new Thread(obj, "One");
		Thread t2 = new Thread(obj, "Two");
		
		// Set priorities for them
		t1.setPriority(2);
		t2.setPriority(Thread.NORM_PRIORITY); // this means priority number 5
		
		// Start first T1 and then T2
		t1.start();
		t2.start();
	}
}

// Thread Unsafe: Two Threads acting on same Object
package com.vodafone.thread;

class Reserve implements Runnable {
	// available berths are 1
	int available = 1;
	int wanted;
	
	// accept wanted berths at run time
	Reserve(int i) {
		wanted = i;
	}
	
	public void run() {
		synchronized (this) { // We are Synchronizing the Current Object at this point
			// display available berths
			System.out.println("Available Berths = " + available);
			// if Available berths are more than wanted berths
			if(available >= wanted) {
				// get name of the passenger
				String name = Thread.currentThread().getName();
				// allot the berth to that passenger
				System.out.println(wanted + " Berths reserved for " + name);
				try {
					Thread.sleep(1500); // wait for printing the ticket
					available = available - wanted;
					// update the no. of available berths
				}catch(InterruptedException ie) {}
			}
			// If berths are less Display Sorry Message to Passenger
			else
				System.out.println("Sorry No Berths are Available");
		}
	}
}

public class UnsafeClass {
	public static void main(String[] args) {
		// Tell that 1 berth is needed
		Reserve obj = new Reserve(1);
		
		// Attach First Thread to the object
		Thread t1 = new Thread(obj);
		
		// Attach Second Thread to the Same object
		Thread t2 = new Thread(obj);
		
		// Take the Thread Names as Passenger Names
		t1.setName("First Passenger");
		t2.setName("Second Passenger");
		
		// send the request for booking berths
		t1.start();
		t2.start();
		
	}
}

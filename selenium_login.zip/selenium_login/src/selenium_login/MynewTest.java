package selenium_login;

import org.testng.annotations.Test;

public class MynewTest {
  @Test
  public void f() {
  }
}
